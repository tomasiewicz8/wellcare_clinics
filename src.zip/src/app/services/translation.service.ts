import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin, map, tap } from 'rxjs';

type TranslationData = Record<string, any>;

@Injectable({
  providedIn: 'root',
})
export class TranslationService {
  private translations: TranslationData = {};

  constructor(private http: HttpClient) {}

  loadLanguage(lang: string) {
    return forkJoin({
      app: this.http.get<TranslationData>(`assets/i18n/${lang}/app.json`),
      navigation: this.http.get<TranslationData>(`assets/i18n/${lang}/navigation.json`),
    }).pipe(
      map((files) => ({
        ...files.app,
        ...files.navigation,
      })),
      tap((translations) => {
        this.translations = translations;
      })
    );
  }

  translate(key: string): string {
    const value = key
      .split('.')
      .reduce<any>((current, part) => current?.[part], this.translations);

    return typeof value === 'string' ? value : key;
  }
}